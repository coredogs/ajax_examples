<?php
echo json_encode( 
    array( 
      'name' => 'Oscar',
      'description' => 'Played Kieran in CoreDogs',
    ) 
);